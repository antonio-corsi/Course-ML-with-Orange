"""Genera il workflow Orange 'demo_text_mining.ows'.

Il file .ows è XML (formato 2.0 di Orange Canvas): nodi (widget), collegamenti, note sul
canvas e impostazioni dei widget. Qui tutte le impostazioni sono scritte in formato "literal"
(un dizionario Python leggibile), senza blocchi binari: per questo la cartella dei testi non
può essere preimpostata e va scelta una volta dentro Import Documents.

Uso:  python crea_workflow.py [percorso_di_uscita.ows]
"""
import sys
import xml.etree.ElementTree as ET

TEXT = "Orange3-Text"
CORE = "Orange3"
W_TEXT = "orangecontrib.text.widgets."
W_CORE = "Orange.widgets."

# ----------------------------------------------------------------------------------------
# NODI: chiave -> (nome del widget, nome qualificato, pacchetto, titolo sul canvas, posizione,
#                  impostazioni). "__version__" è la versione delle impostazioni del widget:
#                  va sempre indicata, altrimenti Orange proverebbe a "migrarle" da zero.
# ----------------------------------------------------------------------------------------
NODI = {
    "import": ("Import Documents", W_TEXT + "owimportdocuments.OWImportDocuments", TEXT,
               "Import Documents", (110, 390),
               {"controlAreaVisible": True, "currentPath": None, "recent_paths": [],
                "recent_urls": [], "source": 0, "lemma_cb": True, "pos_cb": False,
                "ner_cb": False, "__version__": 2}),
    "viewer": ("Corpus Viewer", W_TEXT + "owcorpusviewer.OWCorpusViewer", TEXT,
               "Corpus Viewer", (300, 280),
               {"controlAreaVisible": True, "autocommit": True, "show_tokens": False,
                "__version__": 2}),
    "cloud_prima": ("Word Cloud", W_TEXT + "owwordcloud.OWWordCloud", TEXT,
                    "Word Cloud (prima)", (300, 500),
                    {"controlAreaVisible": True, "words_color": True, "words_tilt": 0,
                     "__version__": 1}),
    "preprocess": ("Preprocess Text", W_TEXT + "owpreprocess.OWPreprocess", TEXT,
                   "Preprocess Text", (580, 390),
                   {"controlAreaVisible": True, "autocommit": True,
                    "storedsettings": {
                        "name": "",
                        "preprocessors": [
                            # Transformation: 0 = Lowercase (tutto in minuscolo)
                            ("preprocess.transform", {"methods": [0]}),
                            # Tokenization: 3 = Regexp, una parola = sequenza di lettere/cifre
                            ("preprocess.tokenize", {"method": 3, "pattern": "\\w+"}),
                            # Filtering: 0 = Stopwords, 2 = Numbers. La lingua NON è indicata:
                            # il widget la prende dal corpus (riconosciuta da Import Documents)
                            ("preprocess.filter", {"methods": [0, 2]}),
                        ]},
                    "__version__": 4}),
    "cloud_dopo": ("Word Cloud", W_TEXT + "owwordcloud.OWWordCloud", TEXT,
                   "Word Cloud (dopo)", (770, 280),
                   {"controlAreaVisible": True, "words_color": True, "words_tilt": 0,
                    "__version__": 1}),
    "bow": ("Bag of Words", W_TEXT + "owbagofwords.OWTBagOfWords", TEXT,
            "Bag of Words", (1230, 390),
            # hidden_cb True = "Hide bow attributes": le colonne delle parole non compaiono
            # negli elenchi di variabili dei widget a valle (es. Corpus Viewer)
            {"controlAreaVisible": True, "autocommit": True, "hidden_cb": True,
             "wlocal": "Count", "wglobal": "(None)", "normalization": "(None)",
             "__version__": 1}),
    "table_bow": ("Data Table", W_CORE + "data.owtable.OWTable", CORE,
                  "Data Table (BoW)", (1420, 280),
                  {"controlAreaVisible": True, "auto_commit": True, "color_by_class": True,
                   "select_rows": True, "show_attribute_labels": True,
                   "show_distributions": False, "__version__": 1}),
    "distances": ("Distances", W_CORE + "unsupervised.owdistances.OWDistances", CORE,
                  "Distances", (1610, 600),
                  # axis 0 = confronto fra righe (documenti); metric_id 4 = Cosine
                  {"controlAreaVisible": True, "autocommit": True, "axis": 0, "metric_id": 4,
                   "__version__": 4}),
    "hclust": ("Hierarchical Clustering",
               W_CORE + "unsupervised.owhierarchicalclustering.OWHierarchicalClustering", CORE,
               "Hierarchical Clustering", (1800, 600),
               # linkage 4 = Ward; selection_method 0 = selezione manuale dei rami
               {"controlAreaVisible": True, "autocommit": True, "linkage": 4,
                "annotation_if_names": "Name", "annotation_if_enumerate": "Enumeration",
                "pruning": 0, "max_depth": 10, "selection_method": 0, "cut_ratio": 75.0,
                "top_n": 4, "zoom_factor": 0, "label_only_subset": False, "__version__": 2}),
    "viewer_gruppo": ("Corpus Viewer", W_TEXT + "owcorpusviewer.OWCorpusViewer", TEXT,
                      "Corpus Viewer (gruppo)", (1990, 530),
                      {"controlAreaVisible": True, "autocommit": True, "show_tokens": False,
                       "__version__": 2}),
    "enrichment": ("Word Enrichment", W_TEXT + "owwordenrichment.OWWordEnrichment", TEXT,
                   "Word Enrichment", (1990, 670),
                   {"controlAreaVisible": True, "auto_apply": True, "filter_by_p": False,
                    "filter_p_value": 0.01, "filter_by_fdr": True, "filter_fdr_value": 0.2,
                    "__version__": 1}),
    "topic": ("Topic Modelling", W_TEXT + "owtopicmodeling.OWTopicModeling", TEXT,
              "Topic Modelling", (770, 770),
              # method_index: 0 = LDA, 1 = LSI, 2 = HDP, 3 = NMF
              {"controlAreaVisible": True, "autocommit": True, "method_index": 3,
               "lda": {"num_topics": 4}, "lsi": {"num_topics": 4}, "nmf": {"num_topics": 4},
               "__version__": 2}),
    "cloud_topic": ("Word Cloud", W_TEXT + "owwordcloud.OWWordCloud", TEXT,
                    "Word Cloud (argomento)", (960, 770),
                    {"controlAreaVisible": True, "words_color": True, "words_tilt": 0,
                     "__version__": 1}),
    "logreg": ("Logistic Regression", W_CORE + "model.owlogisticregression.OWLogisticRegression",
               CORE, "Logistic Regression", (1420, 1120),
               # penalty_type 1 = Ridge (L2); C_index 61 = forza di regolarizzazione C = 1
               {"controlAreaVisible": True, "auto_apply": True, "penalty_type": 1,
                "C_index": 61, "class_weight": False, "__version__": 2}),
    "test": ("Test and Score", W_CORE + "evaluate.owtestandscore.OWTestAndScore", CORE,
             "Test and Score", (1610, 1050),
             # resampling 0 = cross-validation; n_folds 2 = terza voce dell'elenco = 5 parti
             {"controlAreaVisible": True, "resampling": 0, "n_folds": 2, "cv_stratified": True,
              "n_repeats": 3, "sample_size": 9, "shuffle_stratified": True, "use_rope": False,
              "rope": 0.1, "comparison_criterion": 0, "__version__": 4}),
    "confusion": ("Confusion Matrix", W_CORE + "evaluate.owconfusionmatrix.OWConfusionMatrix",
                  CORE, "Confusion Matrix", (1800, 1050),
                  {"controlAreaVisible": True, "autocommit": True, "selected_learner": [0],
                   "selected_quantity": 0, "append_predictions": True,
                   "append_probabilities": False, "__version__": 1}),
    "viewer_errori": ("Corpus Viewer", W_TEXT + "owcorpusviewer.OWCorpusViewer", TEXT,
                      "Corpus Viewer (errori)", (1990, 1050),
                      {"controlAreaVisible": True, "autocommit": True, "show_tokens": False,
                       "__version__": 2}),
    "sentiment": ("Sentiment Analysis", W_TEXT + "owsentimentanalysis.OWSentimentAnalysis", TEXT,
                  "Sentiment Analysis", (770, 1090),
                  # method_idx 2 = Multilingual sentiment; lingua italiana (codice ISO "it")
                  {"controlAreaVisible": True, "autocommit": True, "method_idx": 2,
                   "multi_language": "it", "__version__": 2}),
    "boxplot": ("Box Plot", W_CORE + "visualize.owboxplot.OWBoxPlot", CORE,
                "Box Plot", (960, 1025),
                # compare 2 = confronto delle medie fra i gruppi
                {"controlAreaVisible": True, "compare": 2, "show_annotations": True,
                 "order_by_importance": False, "order_grouping_by_importance": False,
                 "__version__": 1}),
    "table_sentiment": ("Data Table", W_CORE + "data.owtable.OWTable", CORE,
                        "Data Table (sentiment)", (960, 1155),
                        {"controlAreaVisible": True, "auto_commit": True, "color_by_class": True,
                         "select_rows": True, "show_attribute_labels": True,
                         "show_distributions": False, "__version__": 1}),
}

# ----------------------------------------------------------------------------------------
# COLLEGAMENTI: (nodo origine, canale di uscita, id uscita, nodo destinazione, canale di
#                ingresso, id ingresso). Il nome serve alle versioni che non usano gli id.
# ----------------------------------------------------------------------------------------
COLLEGAMENTI = [
    ("import", "Corpus", "data", "viewer", "Corpus", "corpus"),
    ("import", "Corpus", "data", "cloud_prima", "Corpus", "corpus"),
    ("import", "Corpus", "data", "preprocess", "Corpus", "corpus"),
    ("preprocess", "Corpus", "corpus", "cloud_dopo", "Corpus", "corpus"),
    ("preprocess", "Corpus", "corpus", "bow", "Corpus", "corpus"),
    ("bow", "Corpus", "corpus", "table_bow", "Data", "data"),
    ("bow", "Corpus", "corpus", "distances", "Data", "data"),
    ("distances", "Distances", "distances", "hclust", "Distances", "distances"),
    ("hclust", "Selected Data", "selected_data", "viewer_gruppo", "Corpus", "corpus"),
    ("hclust", "Selected Data", "selected_data", "enrichment", "Selected Data", "selected_data"),
    ("hclust", "Data", "annotated_data", "enrichment", "Data", "data"),
    ("preprocess", "Corpus", "corpus", "topic", "Corpus", "corpus"),
    ("topic", "Selected Topic", "selected_topic", "cloud_topic", "Topic", "topic"),
    ("bow", "Corpus", "corpus", "test", "Data", "train_data"),
    ("logreg", "Learner", "learner", "test", "Learner", "learner"),
    ("test", "Evaluation Results", "evaluations_results",
     "confusion", "Evaluation Results", "evaluation_results"),
    ("confusion", "Selected Data", "selected_data", "viewer_errori", "Corpus", "corpus"),
    ("preprocess", "Corpus", "corpus", "sentiment", "Corpus", "corpus"),
    ("sentiment", "Corpus", "corpus", "boxplot", "Data", "data"),
    ("sentiment", "Corpus", "corpus", "table_sentiment", "Data", "data"),
]

# ----------------------------------------------------------------------------------------
# NOTE SUL CANVAS (testo in Markdown): (chiave, rettangolo (x, y, larghezza, altezza),
#                                       dimensione del carattere in pixel, testo)
# ----------------------------------------------------------------------------------------
NOTE = [
    ("intestazione", (40, 20, 1100, 190), 15,
     "**DEMO DI TEXT MINING · 48 messaggi di clienti a una banca**\n\n"
     "Il Text Mining è l'analisi automatica dei testi. In questo workflow leggiamo 48 brevi "
     "messaggi (un file .txt ciascuno, 4 cartelle = 4 categorie) e applichiamo le operazioni "
     "più comuni, seguendo le zone numerate da 1 a 7.\n\n"
     "**Per iniziare:** apriamo *Import Documents* con un doppio clic, premiamo il pulsante con "
     "la cartella e scegliamo la cartella *corpus_demo*: tutti gli altri widget si aggiornano "
     "da soli. Poi salviamo il workflow, così il percorso resta memorizzato. Al primo utilizzo "
     "dell'add-on serve la connessione a Internet, perché vengono scaricati gli elenchi di "
     "stop word."),
    ("zona1", (40, 600, 440, 220), 14,
     "**1 · LETTURA DEI DOCUMENTI**\n\n"
     "*Import Documents* legge tutti i file di una cartella e li riunisce in un **corpus**, cioè "
     "la raccolta dei documenti da analizzare. Il nome della sottocartella diventa la "
     "**categoria** del documento. Con *Corpus Viewer* leggiamo i testi e cerchiamo una parola. "
     "La *Word Cloud (prima)*, cioè la nuvola di parole del testo non ancora pulito, è dominata "
     "da punteggiatura, articoli e preposizioni."),
    ("zona2", (800, 430, 370, 255), 14,
     "**2 · PRE-ELABORAZIONE**\n\n"
     "*Preprocess Text* prepara il testo in tre passi: lo porta in minuscolo, lo divide in "
     "**token** (le singole parole) ed elimina i numeri e le **stop word**, cioè le parole "
     "molto comuni e poco informative (il, di, che…). La lingua viene riconosciuta da *Import "
     "Documents*. Nella *Word Cloud (dopo)* emergono carta, conto, mutuo, rata; restano però "
     "parole generiche (euro, così, senza), che l'elenco standard non contiene."),
    ("zona3", (1160, 20, 500, 195), 14,
     "**3 · BAG OF WORDS**\n\n"
     "*Bag of Words* («sacco di parole») trasforma il testo in numeri: conta quante volte ogni "
     "parola compare in ogni documento, senza tener conto dell'ordine. Ne risulta una tabella "
     "con una riga per documento e una colonna per parola. In *Data Table (BoW)* la vediamo in "
     "forma compatta: l'ultima colonna elenca, per ogni documento, le sole parole presenti con "
     "il loro conteggio (per esempio carta=2)."),
    ("zona4", (1680, 205, 400, 255), 14,
     "**4 · CLUSTERING: gruppi di documenti simili**\n\n"
     "Cerchiamo gruppi senza usare le categorie. *Distances* misura quanto sono diversi due "
     "documenti con la **distanza del coseno**, che confronta le proporzioni delle parole e non "
     "la lunghezza dei testi. *Hierarchical Clustering* disegna il **dendrogramma**, l'albero "
     "che unisce passo dopo passo i documenti più simili. Clicchiamo su un ramo: *Corpus Viewer "
     "(gruppo)* mostra i documenti scelti e *Word Enrichment* le parole che li distinguono dal "
     "resto del corpus."),
    ("zona5", (1050, 705, 300, 265), 14,
     "**5 · TOPIC MODELLING: gli argomenti**\n\n"
     "*Topic Modelling* cerca gli **argomenti** (topic) del corpus: ogni argomento è un insieme "
     "di parole che tendono a comparire negli stessi documenti. Chiediamo 4 argomenti con il "
     "metodo NMF. Clicchiamo su un argomento: *Word Cloud (argomento)* ne mostra le parole più "
     "importanti."),
    ("zona6", (1640, 752, 440, 220), 14,
     "**6 · CLASSIFICAZIONE: prevedere la categoria**\n\n"
     "Insegniamo a un modello a riconoscere la categoria di un messaggio dalle sue parole. "
     "*Logistic Regression* è l'algoritmo che impara; *Test and Score* lo valuta con la "
     "**cross-validation**: a turno una parte dei documenti viene messa da parte e usata solo "
     "per la verifica. *Confusion Matrix* confronta categoria vera e categoria prevista: "
     "selezioniamo le celle degli errori e leggiamo quei messaggi in *Corpus Viewer (errori)*."),
    ("zona7", (1050, 1000, 300, 290), 14,
     "**7 · SENTIMENT (facoltativa)**\n\n"
     "*Sentiment Analysis* dà a ogni messaggio un punteggio di tono: conta le parole positive e "
     "quelle negative di un dizionario italiano e ne fa la differenza, in rapporto alla "
     "lunghezza del testo. Al primo uso il dizionario viene scaricato da Internet. *Box Plot* "
     "confronta i punteggi delle 4 categorie; in *Data Table (sentiment)* ordiniamo la colonna "
     "*sentiment* per leggere i messaggi più negativi."),
    ("prove", (40, 850, 560, 485), 14,
     "**DA PROVARE DAL VIVO**\n\n"
     "- **Zona 2 · stop word aggiuntive.** In *Preprocess Text*, riquadro *Filtering*, accanto "
     "a *Stopwords* premiamo il pulsante con la cartella e carichiamo il file "
     "*extra/stopword_aggiuntive.txt*: dalla nuvola spariscono euro, così, senza.\n"
     "- **Zona 2 · forma base delle parole.** In *Preprocess Text* facciamo doppio clic su "
     "*Normalization* nell'elenco a sinistra e scegliamo *Snowball Stemmer*: le parole vengono "
     "ridotte alla radice, così carta e carte contano come la stessa parola.\n"
     "- **Zona 4 · quattro gruppi.** In *Hierarchical Clustering* scegliamo *Top N* (già "
     "impostato a 4): l'albero viene tagliato in 4 gruppi, da confrontare con le 4 categorie "
     "(il colore delle etichette). Per tornare a esaminare un solo gruppo scegliamo *Manual* e "
     "clicchiamo un ramo. Se le etichette sono numeri, impostiamo *Annotations* = name e *Color "
     "by* = category.\n"
     "- **Zona 5 · un altro metodo.** Passiamo da NMF a LDA, il metodo più noto, e confrontiamo "
     "gli argomenti: con pochi testi brevi risultano di solito meno netti.\n"
     "- **I nostri documenti.** In *Import Documents* scegliamo un'altra cartella di file .txt, "
     ".docx o .pdf, con una sottocartella per ogni categoria."),
]

# freccia rossa dall'intestazione al primo widget da aprire
FRECCE = [((110, 214), (110, 338), "#C1272D")]

TITOLO = "Demo Text Mining - messaggi di clienti a una banca"
DESCRIZIONE = ("Legge una cartella di file di testo (una sottocartella per categoria) e applica le "
               "operazioni tipiche del Text Mining: pre-elaborazione, nuvola di parole, bag of "
               "words, clustering gerarchico, topic modelling, classificazione, sentiment.")


def costruisci():
    radice = ET.Element("scheme", {"version": "2.0", "title": TITOLO, "description": DESCRIZIONE})
    ids = {chiave: str(i) for i, chiave in enumerate(NODI)}

    nodi = ET.SubElement(radice, "nodes")
    for chiave, (nome, qualificato, pacchetto, titolo, pos, _) in NODI.items():
        ET.SubElement(nodi, "node", {
            "id": ids[chiave], "name": nome, "qualified_name": qualificato,
            "project_name": pacchetto, "version": "", "title": titolo,
            "position": "(%.1f, %.1f)" % pos})

    collegamenti = ET.SubElement(radice, "links")
    for i, (da, canale_da, id_da, a, canale_a, id_a) in enumerate(COLLEGAMENTI):
        ET.SubElement(collegamenti, "link", {
            "id": str(i), "source_node_id": ids[da], "sink_node_id": ids[a],
            "source_channel": canale_da, "sink_channel": canale_a, "enabled": "true",
            "source_channel_id": id_da, "sink_channel_id": id_a})

    annotazioni = ET.SubElement(radice, "annotations")
    n = 0
    for (p1, p2, colore) in FRECCE:
        ET.SubElement(annotazioni, "arrow", {
            "id": str(n), "start": "(%.1f, %.1f)" % p1, "end": "(%.1f, %.1f)" % p2,
            "fill": colore})
        n += 1
    for _, rett, corpo, testo in NOTE:
        el = ET.SubElement(annotazioni, "text", {
            "id": str(n), "type": "text/markdown",
            "rect": "(%.1f, %.1f, %.1f, %.1f)" % rett, "font-size": str(corpo)})
        el.text = testo
        n += 1

    ET.SubElement(radice, "thumbnail")

    proprieta = ET.SubElement(radice, "node_properties")
    for chiave, (*_, impostazioni) in NODI.items():
        el = ET.SubElement(proprieta, "properties", {"node_id": ids[chiave], "format": "literal"})
        el.text = repr(impostazioni)

    stato = ET.SubElement(radice, "session_state")
    ET.SubElement(stato, "window_groups")
    return radice


def scrivi(percorso):
    radice = costruisci()
    ET.indent(radice, space="\t")
    # ET.indent non deve toccare il testo delle note e delle impostazioni: agisce solo sugli
    # elementi senza testo, quindi i contenuti restano intatti
    ET.ElementTree(radice).write(percorso, encoding="utf-8", xml_declaration=True)
    return percorso


if __name__ == "__main__":
    uscita = sys.argv[1] if len(sys.argv) > 1 else "demo_text_mining.ows"
    scrivi(uscita)
    print("scritto", uscita, "|", len(NODI), "widget,", len(COLLEGAMENTI), "collegamenti,",
          len(NOTE), "note")
