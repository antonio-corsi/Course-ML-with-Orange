# Demo di Text Mining con Orange

Workflow dimostrativo per l'add-on **Text** di Orange Data Mining: legge una cartella di file di
testo e applica le operazioni più comuni del Text Mining (l'analisi automatica dei testi).

## Contenuto della cartella

| Elemento | Che cos'è |
|---|---|
| `demo_text_mining.ows` | Il workflow: 20 widget in 7 zone numerate, con note in italiano sul canvas |
| `corpus_demo/` | 48 messaggi inventati di clienti a una banca, un file `.txt` per messaggio, in 4 sottocartelle (= 4 categorie): `carte`, `conto_bonifici`, `investimenti`, `mutui_prestiti` |
| `extra/stopword_aggiuntive.txt` | Elenco facoltativo di parole generiche (euro, così, senza…) da caricare in *Preprocess Text* come prova dal vivo |
| `extra/chiave_documenti.csv` | Per chi conduce la demo: tono di ogni messaggio (reclamo, richiesta, apprezzamento) e documenti «di confine», scritti apposta con parole di due categorie |
| `extra/crea_workflow.py` | Lo script Python che ha generato il file `.ows`: utile per cambiare posizioni, note o impostazioni e rigenerare il workflow (`python crea_workflow.py demo_text_mining.ows`) |

## Come si usa

1. Estrarre lo zip mantenendo la struttura delle cartelle.
2. Aprire `demo_text_mining.ows` in Orange.
3. Aprire *Import Documents* con un doppio clic, premere il pulsante con la cartella e selezionare
   `corpus_demo` (la cartella che contiene le 4 sottocartelle). Nel riquadro *Info* deve comparire
   «48 documents / 4 categories» e nel riquadro *Language* la voce *Italian*. Tutti gli altri
   widget si aggiornano da soli.
4. Salvare il workflow: da quel momento il percorso della cartella resta memorizzato.

La cartella va selezionata a mano perché il percorso dipende dal computer e *Import Documents*
non accetta percorsi relativi al file del workflow.

## Le 7 zone

| Zona | Widget | Che cosa si mostra |
|---|---|---|
| 1 · Lettura | Import Documents, Corpus Viewer, Word Cloud (prima) | Il corpus (la raccolta dei documenti), la categoria ricavata dal nome della sottocartella, la nuvola di parole del testo non ancora pulito |
| 2 · Pre-elaborazione | Preprocess Text, Word Cloud (dopo) | Minuscolo, divisione in token (le singole parole), eliminazione di numeri e stop word (parole molto comuni e poco informative) |
| 3 · Bag of Words | Bag of Words, Data Table (BoW) | La tabella documenti × parole con i conteggi: il testo diventa numeri. In *Data Table* compare in forma compatta: per ogni documento l'elenco delle parole presenti con il conteggio |
| 4 · Clustering | Distances, Hierarchical Clustering, Corpus Viewer (gruppo), Word Enrichment | Gruppi di documenti simili trovati senza usare le categorie; parole tipiche di un gruppo |
| 5 · Topic modelling | Topic Modelling, Word Cloud (argomento) | 4 argomenti (insiemi di parole che compaiono insieme) con il metodo NMF |
| 6 · Classificazione | Logistic Regression, Test and Score, Confusion Matrix, Corpus Viewer (errori) | Previsione della categoria dalle parole, valutata in cross-validation; lettura dei messaggi classificati male |
| 7 · Sentiment (facoltativa) | Sentiment Analysis, Box Plot, Data Table (sentiment) | Punteggio di tono basato su un dizionario italiano di parole positive e negative |

Ogni zona si può mostrare da sola; quelle che non servono si possono cancellare dal canvas.

## Che cosa aspettarsi

I valori che seguono vengono da una prova fatta **fuori da Orange**, ripetendo gli stessi passi con
scikit-learn e scipy sui file di `corpus_demo`. In Orange possono differire di poco.

- **Word Cloud (dopo)**: carta, conto, mutuo, rata in evidenza, insieme a parole generiche come
  euro, stata, così, può, senza, che spariscono caricando `extra/stopword_aggiuntive.txt`.
- **Bag of Words**: 48 righe e circa 800 parole distinte. In *Data Table (BoW)* l'ultima colonna
  elenca, per ogni documento, le parole presenti con il loro conteggio.
- **Clustering**: tagliando il dendrogramma in 4 gruppi (*Top N* = 4), 46 documenti su 48 cadono nel
  gruppo della propria categoria. I due fuori posto sono `mutui_03` e `invest_12`, due documenti di
  confine che parlano anche di conto corrente.
- **Classificazione**: accuratezza intorno al 95%. Gli errori ricorrenti sono `mutui_03`,
  `invest_02` e `invest_12`, previsti come `conto_bonifici`: sono proprio i documenti di confine.
- **Topic modelling**: con NMF quattro argomenti leggibili (conto e bonifici, carte, mutui,
  investimenti). Con LDA, su così pochi testi brevi, gli argomenti risultano di solito più confusi.
- **Sentiment**: non verificato in anticipo, perché il dizionario viene scaricato da Orange al primo
  uso. È un metodo che conta parole: ad esempio `carte_11` è un ringraziamento ma contiene furto,
  preoccupazione, difficile. Il file `extra/chiave_documenti.csv` riporta il tono vero di ogni
  messaggio per il confronto.

## Avvertenze

- **Non aggiungere altri file dentro `corpus_demo`.** *Import Documents* legge come documenti tutti i
  file `.txt`, `.docx`, `.odt`, `.pdf`, `.xml` che trova, anche nelle sottocartelle, e interpreta i
  file `.csv`, `.tsv` e `.yaml` come metadati. Per questo i file facoltativi stanno in `extra/`.
- **Connessione a Internet al primo utilizzo.** L'add-on scarica gli elenchi di stop word la prima
  volta che viene avviato e il dizionario del sentiment la prima volta che si usa la zona 7.
- **Versioni.** Nomi dei widget, canali e impostazioni sono stati controllati sul codice sorgente di
  Orange 3.38.1 e 3.41.0 e dell'add-on Text 1.16.3. Il workflow non è stato aperto in Orange.
- **Python 3.13.** Dalla lettura del codice risulta che l'add-on Text 1.16.3, eseguito con
  Python 3.13, non riesce a creare il widget *Preprocess Text* (errore
  `'method' object is not iterable`). In quel caso il problema è dell'add-on, non del workflow:
  serve un ambiente con Python 3.11 o 3.12.
- **Etichette del dendrogramma.** Se compaiono numeri al posto dei nomi dei file, impostare in
  *Hierarchical Clustering* *Annotations* = name e *Color by* = category.
- **Top N e Word Enrichment.** Con *Top N* = 4 tutti i documenti risultano selezionati e
  *Word Enrichment* segnala «All examples can not be selected!»: è il comportamento previsto.
  Per vedere le parole tipiche di un gruppo, scegliere *Manual* e cliccare un solo ramo.

## Usare i propri documenti

Preparare una cartella con una sottocartella per categoria e selezionarla in *Import Documents*.
La lingua viene riconosciuta automaticamente e si può correggere nello stesso widget; l'elenco di
stop word di *Preprocess Text* segue la lingua del corpus.

Per documenti in una lingua diversa dall'italiano:

- dopo aver salvato il workflow la lingua delle stop word resta memorizzata: controllarla nel
  riquadro *Filtering* di *Preprocess Text*;
- in *Sentiment Analysis* la lingua italiana è impostata in modo esplicito e va cambiata a mano.
